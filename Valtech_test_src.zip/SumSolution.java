package befaster.solutions.SUM;

public class SumSolution {

    public int compute(int x, int y) {
        return x + y;
    }

}
