package befaster.solutions.HLO;

public class HelloSolution {
    public String hello(String friendName) {
        return "Hello, " + friendName + "!";
        //return "Hello, World!";
    }
}
